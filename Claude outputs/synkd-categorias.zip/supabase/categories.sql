-- Categorías editables desde /admin.
-- Pégalo completo en Supabase -> SQL Editor -> Run. Se puede correr más de una vez sin romper nada.

create table if not exists public.categories (
  slug        text primary key,                                  -- va en la URL: /shop?cat=<slug>  (no se edita después de crear)
  label       text not null,                                     -- nombre que ve el cliente
  sizes       text[] not null default '{S,M,L,XL,XXL}',          -- tallas que ofrece esa categoría
  image_url   text,                                              -- foto del cuadro en el Home (null = usa la foto local de siempre)
  sort_order  integer not null default 0,
  created_at  timestamptz not null default now(),
  constraint categories_slug_format check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
  constraint categories_slug_reserved check (slug <> 'all'),
  constraint categories_label_not_empty check (length(btrim(label)) > 0),
  constraint categories_sizes_not_empty check (array_length(sizes, 1) > 0)
);

alter table public.categories enable row level security;

-- Cualquiera puede LEER (la tienda pública las necesita)
drop policy if exists "categories_public_read" on public.categories;
create policy "categories_public_read" on public.categories
  for select to anon, authenticated using (true);

-- Solo usuarios con sesión iniciada (el admin) pueden crear / editar / borrar.
-- Es seguro mientras "Allow new users to sign up" siga APAGADO en Authentication.
drop policy if exists "categories_admin_insert" on public.categories;
create policy "categories_admin_insert" on public.categories
  for insert to authenticated with check (true);

drop policy if exists "categories_admin_update" on public.categories;
create policy "categories_admin_update" on public.categories
  for update to authenticated using (true) with check (true);

drop policy if exists "categories_admin_delete" on public.categories;
create policy "categories_admin_delete" on public.categories
  for delete to authenticated using (true);

-- Candado en la base de datos: no deja borrar una categoría que todavía tiene productos
-- (si no, esos productos quedarían huérfanos, sin aparecer en ningún menú).
create or replace function public.block_category_delete_if_used()
returns trigger language plpgsql as $$
begin
  if exists (select 1 from public.products where category = old.slug) then
    raise exception 'Esta categoría todavía tiene productos. Muévelos o bórralos primero.';
  end if;
  return old;
end;
$$;

drop trigger if exists categories_block_delete on public.categories;
create trigger categories_block_delete
  before delete on public.categories
  for each row execute function public.block_category_delete_if_used();

-- Las 3 categorías que ya existen (si ya están, no las toca)
insert into public.categories (slug, label, sizes, sort_order) values
  ('tshirts', 'T-Shirts', '{S,M,L,XL,XXL}',               1),
  ('shorts',  'Shorts',   '{26,28,30,32,34,36,38}',       2),
  ('alo',     'Alo',      '{S,M,L,XL,XXL}',               3)
on conflict (slug) do nothing;
